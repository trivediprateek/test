.. _template_api:

Template
========

.. autoclass:: rtcclient.template.Templater
   :members:
