.. _projectarea_api:

ProjectArea
===========

.. autoclass:: rtcclient.project_area.ProjectArea
   :members:
