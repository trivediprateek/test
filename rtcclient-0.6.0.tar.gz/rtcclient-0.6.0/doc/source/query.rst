.. _query_api:

Query
=====

.. autoclass:: rtcclient.query.Query
   :members:
