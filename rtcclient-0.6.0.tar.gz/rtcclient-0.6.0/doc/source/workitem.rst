.. _workitem_api:

Workitem
========

.. autoclass:: rtcclient.workitem.Workitem
   :members:
