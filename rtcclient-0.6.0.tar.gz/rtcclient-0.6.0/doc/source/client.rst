.. _client_api:

Client
======

.. autoclass:: rtcclient.client.RTCClient
   :members:
